export class UpdateProductDto{
    readonly tempr: number
    readonly methane: number
    readonly ethane: number
    readonly propane: number
}